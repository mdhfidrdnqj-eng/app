<?php
require_once '../config.php';
requireAdmin();

$pdo = getDB();
$input = json_decode(file_get_contents('php://input'), true);
$requestId = $input['request_id'] ?? 0;

if (!$requestId) {
    echo json_encode(['error' => 'Invalid request ID']);
    exit;
}

// جلب الطلب
$stmt = $pdo->prepare("SELECT * FROM currency_requests WHERE id = ?");
$stmt->execute([$requestId]);
$request = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$request) {
    echo json_encode(['error' => 'Request not found']);
    exit;
}

// إنشاء العملة
$currencyId = strtolower($request['symbol']) . '_' . time();

$stmt = $pdo->prepare("
    INSERT INTO currencies (id, name, symbol, total_supply, circulating_supply, liquidity, is_main, status, created_by, created_at, image, description, price_history) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
");

$circulatingSupply = $request['total_supply'];
$stmt->execute([
    $currencyId,
    $request['name'],
    $request['symbol'],
    $request['total_supply'],
    $circulatingSupply,
    0,
    0,
    'active',
    $request['created_by'],
    time(),
    $request['image'],
    $request['description'],
    json_encode([0])
]);

// منح العملة للمنشئ
updateBalance($pdo, $request['created_by'], $currencyId, $circulatingSupply);

// تحديث حالة الطلب
$stmt = $pdo->prepare("UPDATE currency_requests SET status = 'approved' WHERE id = ?");
$stmt->execute([$requestId]);

echo json_encode(['success' => true, 'message' => 'تمت الموافقة على العملة']);
?>