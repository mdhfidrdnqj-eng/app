<?php
require_once '../config.php';
requireAdmin();

$pdo = getDB();

$stmt = $pdo->prepare("
    SELECT d.*, u.name as user_name 
    FROM deposit_requests d
    LEFT JOIN users u ON d.user_id = u.id
    WHERE d.status = 'pending'
    ORDER BY d.created_at DESC
");
$stmt->execute();
$deposits = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode(['success' => true, 'deposits' => $deposits]);
?>