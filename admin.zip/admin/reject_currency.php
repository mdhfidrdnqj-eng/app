<?php
require_once '../config.php';
requireAdmin();

$pdo = getDB();
$input = json_decode(file_get_contents('php://input'), true);
$requestId = $input['request_id'] ?? 0;

if (!$requestId) {
    echo json_encode(['error' => 'Invalid request ID']);
    exit;
}

$stmt = $pdo->prepare("UPDATE currency_requests SET status = 'rejected' WHERE id = ?");
$stmt->execute([$requestId]);

echo json_encode(['success' => true, 'message' => 'تم رفض الطلب']);
?>