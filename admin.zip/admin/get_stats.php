<?php
require_once '../config.php';
requireAdmin();

$pdo = getDB();

// عدد المستخدمين
$stmt = $pdo->query("SELECT COUNT(*) as total FROM users");
$totalUsers = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

// عدد العملات
$stmt = $pdo->query("SELECT COUNT(*) as total FROM currencies WHERE is_main = 0 AND status = 'active'");
$totalCurrencies = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

// حجم التداول
$stmt = $pdo->query("SELECT SUM(amount) as total FROM transactions");
$totalVolume = $stmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;

// طلبات معلقة
$stmt = $pdo->query("SELECT COUNT(*) as pending FROM currency_requests WHERE status = 'pending'");
$pendingRequests = $stmt->fetch(PDO::FETCH_ASSOC)['pending'];

$stmt = $pdo->query("SELECT COUNT(*) as pending FROM deposit_requests WHERE status = 'pending'");
$pendingDeposits = $stmt->fetch(PDO::FETCH_ASSOC)['pending'];

echo json_encode([
    'success' => true,
    'stats' => [
        'total_users' => $totalUsers,
        'total_currencies' => $totalCurrencies,
        'total_volume_gco' => round($totalVolume, 2),
        'pending_requests' => $pendingRequests,
        'pending_deposits' => $pendingDeposits
    ]
]);
?>