<?php
require_once '../config.php';
requireAdmin();

$pdo = getDB();

$stmt = $pdo->prepare("
    SELECT r.*, u.name as creator_name 
    FROM currency_requests r
    LEFT JOIN users u ON r.created_by = u.id
    WHERE r.status = 'pending'
    ORDER BY r.created_at DESC
");
$stmt->execute();
$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode(['success' => true, 'requests' => $requests]);
?>