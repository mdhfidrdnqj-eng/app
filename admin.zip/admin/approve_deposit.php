<?php
require_once '../config.php';
requireAdmin();

$pdo = getDB();
$input = json_decode(file_get_contents('php://input'), true);
$depositId = $input['deposit_id'] ?? 0;

if (!$depositId) {
    echo json_encode(['error' => 'Invalid deposit ID']);
    exit;
}

// جلب طلب الشحن
$stmt = $pdo->prepare("SELECT * FROM deposit_requests WHERE id = ?");
$stmt->execute([$depositId]);
$deposit = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$deposit) {
    echo json_encode(['error' => 'Deposit not found']);
    exit;
}

// إضافة الرصيد للمستخدم
updateBalance($pdo, $deposit['user_id'], MAIN_CURRENCY_ID, $deposit['amount']);

// تحديث حالة الطلب
$stmt = $pdo->prepare("UPDATE deposit_requests SET status = 'approved' WHERE id = ?");
$stmt->execute([$depositId]);

// تسجيل المعاملة
addTransaction($pdo, 0, $deposit['user_id'], MAIN_CURRENCY_ID, $deposit['amount'], 'شحن رصيد عبر التحويل البنكي');

echo json_encode(['success' => true, 'message' => 'تمت الموافقة على الشحن']);
?>