<?php
require_once '../config.php';
requireAdmin();

$pdo = getDB();

$stmt = $pdo->query("
    SELECT u.*, 
           (SELECT COUNT(*) FROM transactions WHERE from_user_id = u.id OR to_user_id = u.id) as tx_count
    FROM users u 
    ORDER BY u.created_at DESC
");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($users as &$user) {
    $user['total_balance'] = 0;
    $stmt2 = $pdo->prepare("SELECT SUM(amount * c.price) as total 
                            FROM balances b 
                            LEFT JOIN currencies c ON b.currency_id = c.id 
                            WHERE b.user_id = ?");
    $stmt2->execute([$user['id']]);
    $result = $stmt2->fetch(PDO::FETCH_ASSOC);
    $user['total_balance'] = round($result['total'] ?? 0, 2);
}

echo json_encode(['success' => true, 'users' => $users]);
?>