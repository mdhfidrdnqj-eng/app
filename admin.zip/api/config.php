<?php
/**
 * ============================================
 * VAULTX - CONFIGURATION FILE
 * ============================================
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// إعدادات قاعدة البيانات - قم بتعديلها
define('DB_HOST', 'sql303.ezyro.com');
define('DB_NAME', 'ezyro_41832117_xena');
define('DB_USER', 'ezyro_41832117');
define('DB_PASS', '2b94dc9d4');

// إعدادات التطبيق
define('ADMIN_IDS', '6187252111');
define('CURRENCY_CREATION_FEE', 5);
define('MAIN_CURRENCY_ID', 'gco_main');
define('MAIN_CURRENCY_SYMBOL', 'GCO');
define('GCO_TO_IQD', 1000);
define('PRICE_INCREASE_FACTOR', 0.000001);
define('SITE_URL', 'https://pay-xenalive-me-webpay-index.unaux.com');

// الاتصال بقاعدة البيانات
function getDB() {
    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        return $pdo;
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Database connection failed']);
        exit;
    }
}

session_start();

function requireAuth() {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Unauthorized']);
        exit;
    }
}

function isAdmin($userId) {
    $adminIds = explode(',', ADMIN_IDS);
    return in_array($userId, $adminIds);
}

function requireAdmin() {
    requireAuth();
    if (!isAdmin($_SESSION['user_id'])) {
        http_response_code(403);
        echo json_encode(['error' => 'Admin access required']);
        exit;
    }
}

// حل مشكلة +Infinity%
function calculatePriceChange($priceHistory) {
    if (!$priceHistory || !is_array($priceHistory) || count($priceHistory) < 2) {
        return 0;
    }
    
    $oldPrice = floatval($priceHistory[0]);
    $newPrice = floatval($priceHistory[count($priceHistory) - 1]);
    
    if ($oldPrice == 0) {
        return $newPrice > 0 ? 100 : 0;
    }
    
    $change = (($newPrice - $oldPrice) / $oldPrice) * 100;
    
    if (is_nan($change) || is_infinite($change)) return 0;
    if ($change > 1000) return 1000;
    if ($change < -100) return -100;
    
    return round($change, 2);
}

// تحديث سعر العملة
function updateCurrencyPrice($pdo, $currencyId) {
    if ($currencyId == MAIN_CURRENCY_ID) {
        return GCO_TO_IQD;
    }
    
    $stmt = $pdo->prepare("SELECT liquidity, circulating_supply, price_history, trade_count FROM currencies WHERE id = ?");
    $stmt->execute([$currencyId]);
    $currency = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$currency) return 0;
    
    $basePrice = $currency['circulating_supply'] > 0 
        ? $currency['liquidity'] / $currency['circulating_supply'] 
        : 0;
    
    $tradeBonus = $currency['trade_count'] * PRICE_INCREASE_FACTOR * $basePrice;
    $newPrice = $basePrice + $tradeBonus;
    
    if ($newPrice <= 0 && $basePrice > 0) $newPrice = $basePrice;
    if ($newPrice < 0) $newPrice = 0;
    
    $history = json_decode($currency['price_history'], true) ?: [];
    $history[] = $newPrice;
    if (count($history) > 20) array_shift($history);
    
    $stmt2 = $pdo->prepare("UPDATE currencies SET price = ?, price_history = ? WHERE id = ?");
    $stmt2->execute([$newPrice, json_encode($history), $currencyId]);
    
    return $newPrice;
}

function getUserBalance($pdo, $userId, $currencyId) {
    $stmt = $pdo->prepare("SELECT amount FROM balances WHERE user_id = ? AND currency_id = ?");
    $stmt->execute([$userId, $currencyId]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result ? floatval($result['amount']) : 0;
}

function updateBalance($pdo, $userId, $currencyId, $amount) {
    $stmt = $pdo->prepare(
        "INSERT INTO balances (user_id, currency_id, amount) 
         VALUES (?, ?, ?) 
         ON DUPLICATE KEY UPDATE amount = amount + ?"
    );
    return $stmt->execute([$userId, $currencyId, $amount, $amount]);
}

function addTransaction($pdo, $fromUserId, $toUserId, $currencyId, $amount, $note = '') {
    $stmt = $pdo->prepare(
        "INSERT INTO transactions (from_user_id, to_user_id, currency_id, amount, note, ts) 
         VALUES (?, ?, ?, ?, ?, ?)"
    );
    return $stmt->execute([$fromUserId, $toUserId, $currencyId, $amount, $note, time()]);
}

// إنشاء المجلدات
if (!file_exists(__DIR__ . '/uploads/deposits')) {
    mkdir(__DIR__ . '/uploads/deposits', 0777, true);
}
if (!file_exists(__DIR__ . '/uploads/currencies')) {
    mkdir(__DIR__ . '/uploads/currencies', 0777, true);
}
?>