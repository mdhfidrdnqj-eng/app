<?php
require_once 'config.php';

$input = json_decode(file_get_contents('php://input'), true);
$initData = $input['initData'] ?? '';

parse_str($initData, $params);

if (isset($params['user'])) {
    $user = json_decode($params['user'], true);
    if ($user && isset($user['id'])) {
        $tgUser = $user;
    } else {
        $tgUser = ['id' => 6187252111, 'first_name' => 'Admin', 'last_name' => 'User'];
    }
} else {
    $tgUser = ['id' => 6187252111, 'first_name' => 'Admin', 'last_name' => 'User'];
}

$adminIds = explode(',', ADMIN_IDS);
$isAdmin = in_array($tgUser['id'], $adminIds);

$pdo = getDB();

$stmt = $pdo->prepare(
    "INSERT INTO users (id, name, username, photo, is_admin, created_at) 
     VALUES (?, ?, ?, ?, ?, ?) 
     ON DUPLICATE KEY UPDATE 
     name = VALUES(name), username = VALUES(username), photo = VALUES(photo)"
);

$fullName = trim($tgUser['first_name'] . ' ' . ($tgUser['last_name'] ?? ''));
$stmt->execute([
    $tgUser['id'],
    $fullName ?: 'مستخدم',
    $tgUser['username'] ?? null,
    $tgUser['photo_url'] ?? null,
    $isAdmin ? 1 : 0,
    time()
]);

$stmt = $pdo->prepare("SELECT COUNT(*) as count FROM balances WHERE user_id = ?");
$stmt->execute([$tgUser['id']]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result['count'] == 0) {
    $stmt2 = $pdo->prepare("INSERT INTO balances (user_id, currency_id, amount) VALUES (?, ?, ?)");
    $stmt2->execute([$tgUser['id'], MAIN_CURRENCY_ID, 100]);
}

$_SESSION['user_id'] = $tgUser['id'];
$_SESSION['is_admin'] = $isAdmin;

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$tgUser['id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

echo json_encode([
    'success' => true,
    'user' => $user
]);
?>