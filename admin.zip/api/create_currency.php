<?php
require_once 'config.php';
requireAuth();

$pdo = getDB();
$userId = $_SESSION['user_id'];

$input = json_decode(file_get_contents('php://input'), true);

$name = $input['name'] ?? '';
$symbol = strtoupper($input['symbol'] ?? '');
$totalSupply = floatval($input['total_supply'] ?? 0);
$description = $input['description'] ?? '';
$imageBase64 = $input['image'] ?? null;

if (empty($name) || empty($symbol) || $totalSupply <= 0) {
    echo json_encode(['error' => 'الرجاء إدخال اسم العملة والرمز والكمية']);
    exit;
}

if ($totalSupply > 1000000000) {
    echo json_encode(['error' => 'الكمية القصوى هي 1,000,000,000']);
    exit;
}

// التحقق من الرمز
$stmt = $pdo->prepare("SELECT COUNT(*) FROM currencies WHERE symbol = ?");
$stmt->execute([$symbol]);
if ($stmt->fetchColumn() > 0) {
    echo json_encode(['error' => 'الرمز مستخدم بالفعل']);
    exit;
}

// التحقق من رصيد GCO للرسوم
$mainBalance = getUserBalance($pdo, $userId, MAIN_CURRENCY_ID);
if ($mainBalance < CURRENCY_CREATION_FEE) {
    echo json_encode(['error' => 'لا يوجد رصيد كافي من GCO لدفع رسوم الإنشاء (' . CURRENCY_CREATION_FEE . ' GCO)']);
    exit;
}

// خصم الرسوم
updateBalance($pdo, $userId, MAIN_CURRENCY_ID, -CURRENCY_CREATION_FEE);
addTransaction($pdo, $userId, 0, MAIN_CURRENCY_ID, CURRENCY_CREATION_FEE, 'رسوم إنشاء عملة جديدة');

// حفظ الصورة
$imagePath = null;
if ($imageBase64) {
    $matches = [];
    if (preg_match('/^data:image\/(\w+);base64,(.+)$/', $imageBase64, $matches)) {
        $ext = $matches[1];
        $filename = time() . '_' . rand(1000, 9999) . '.' . $ext;
        $filepath = __DIR__ . '/uploads/currencies/' . $filename;
        file_put_contents($filepath, base64_decode($matches[2]));
        $imagePath = '/api/uploads/currencies/' . $filename;
    }
}

// إنشاء طلب العملة
$stmt = $pdo->prepare("
    INSERT INTO currency_requests (name, symbol, total_supply, description, image, created_by, created_at, status) 
    VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')
");
$stmt->execute([$name, $symbol, $totalSupply, $description, $imagePath, $userId, time()]);

echo json_encode([
    'success' => true,
    'message' => 'تم إرسال طلب إنشاء العملة للمراجعة'
]);
?>