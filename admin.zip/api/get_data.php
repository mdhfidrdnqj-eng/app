<?php
require_once 'config.php';
requireAuth();

$pdo = getDB();
$userId = $_SESSION['user_id'];

// جلب العملات - العملة الرئيسية + أول 10 عملات نشطة
$stmt = $pdo->prepare("
    SELECT * FROM currencies 
    WHERE status = 'active' 
    ORDER BY 
        CASE WHEN is_main = 1 THEN 0 ELSE 1 END,
        created_at DESC 
    LIMIT 11
");
$stmt->execute();
$currencies = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($currencies as &$c) {
    $priceHistory = json_decode($c['price_history'], true) ?: [];
    $c['price_change'] = calculatePriceChange($priceHistory);
    $c['price_history'] = $priceHistory;
    
    if ($c['is_main']) {
        $c['price_display'] = number_format($c['price'], 2);
        $c['price_iqd'] = number_format($c['price'] * GCO_TO_IQD, 0) . ' IQD';
    } else {
        $c['price_display'] = number_format($c['price'], 8);
    }
}

// جلب أرصدة المستخدم
$stmt = $pdo->prepare("SELECT * FROM balances WHERE user_id = ?");
$stmt->execute([$userId]);
$balances = $stmt->fetchAll(PDO::FETCH_ASSOC);

// جلب المعاملات
$stmt = $pdo->prepare("
    SELECT * FROM transactions 
    WHERE from_user_id = ? OR to_user_id = ? 
    ORDER BY ts DESC LIMIT 50
");
$stmt->execute([$userId, $userId]);
$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

// جلب طلبات الشحن
$stmt = $pdo->prepare("SELECT * FROM deposit_requests WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$userId]);
$deposits = $stmt->fetchAll(PDO::FETCH_ASSOC);

// إحصائيات
$stmt = $pdo->prepare("
    SELECT COUNT(DISTINCT currency_id) as my_currencies 
    FROM balances 
    WHERE user_id = ? AND amount > 0 AND currency_id != ?
");
$stmt->execute([$userId, MAIN_CURRENCY_ID]);
$myCurrencies = $stmt->fetch(PDO::FETCH_ASSOC);

$totalValue = 0;
foreach ($balances as $bal) {
    $currency = array_filter($currencies, fn($c) => $c['id'] == $bal['currency_id']);
    $currency = reset($currency);
    if ($currency) {
        $totalValue += $bal['amount'] * $currency['price'];
    }
}

echo json_encode([
    'success' => true,
    'currencies' => $currencies,
    'balances' => $balances,
    'transactions' => $transactions,
    'deposits' => $deposits,
    'stats' => [
        'my_currencies' => $myCurrencies['my_currencies'] ?? 0,
        'total_transactions' => count($transactions),
        'total_value_gco' => round($totalValue, 2),
        'total_value_iqd' => number_format($totalValue * GCO_TO_IQD, 0)
    ],
    'gco_to_iqd' => GCO_TO_IQD
]);
?>