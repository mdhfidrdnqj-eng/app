<?php
require_once 'config.php';
requireAuth();

$pdo = getDB();
$userId = $_SESSION['user_id'];

$input = json_decode(file_get_contents('php://input'), true);

$toUserId = $input['to_user_id'] ?? 0;
$currencyId = $input['currency_id'] ?? '';
$amount = floatval($input['amount'] ?? 0);
$note = $input['note'] ?? '';

if (!$toUserId || !$currencyId || $amount <= 0) {
    echo json_encode(['error' => 'بيانات غير صالحة']);
    exit;
}

// التحقق من المستلم
$stmt = $pdo->prepare("SELECT id FROM users WHERE id = ?");
$stmt->execute([$toUserId]);
if (!$stmt->fetch()) {
    echo json_encode(['error' => 'المستلم غير موجود']);
    exit;
}

// التحقق من العملة
$stmt = $pdo->prepare("SELECT * FROM currencies WHERE id = ? AND status = 'active'");
$stmt->execute([$currencyId]);
$currency = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$currency) {
    echo json_encode(['error' => 'العملة غير متوفرة']);
    exit;
}

// التحقق من الرصيد
$balance = getUserBalance($pdo, $userId, $currencyId);
if ($balance < $amount) {
    echo json_encode(['error' => 'رصيد غير كاف']);
    exit;
}

// تنفيذ التحويل
updateBalance($pdo, $userId, $currencyId, -$amount);
updateBalance($pdo, $toUserId, $currencyId, $amount);
addTransaction($pdo, $userId, $toUserId, $currencyId, $amount, $note);

// زيادة عدد التداولات وتحديث السعر (للعملات غير الرئيسية)
if (!$currency['is_main']) {
    $stmt = $pdo->prepare("UPDATE currencies SET trade_count = trade_count + 1 WHERE id = ?");
    $stmt->execute([$currencyId]);
    updateCurrencyPrice($pdo, $currencyId);
}

echo json_encode(['success' => true, 'message' => 'تم الإرسال بنجاح']);
?>