<?php
require_once 'config.php';
requireAuth();

$pdo = getDB();
$userId = $_SESSION['user_id'];

$input = json_decode(file_get_contents('php://input'), true);

$currencyId = $input['currency_id'] ?? '';
$amount = floatval($input['amount'] ?? 0);

if (!$currencyId || $amount <= 0) {
    echo json_encode(['error' => 'بيانات غير صالحة']);
    exit;
}

// التحقق من العملة
$stmt = $pdo->prepare("SELECT * FROM currencies WHERE id = ? AND status = 'active' AND is_main = 0");
$stmt->execute([$currencyId]);
$currency = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$currency) {
    echo json_encode(['error' => 'العملة غير موجودة أو غير نشطة']);
    exit;
}

// التحقق من أن المستخدم هو مالك العملة
if ($currency['created_by'] != $userId) {
    echo json_encode(['error' => 'أنت لست مالك هذه العملة']);
    exit;
}

// التحقق من رصيد GCO
$gcoBalance = getUserBalance($pdo, $userId, MAIN_CURRENCY_ID);
if ($gcoBalance < $amount) {
    echo json_encode(['error' => 'رصيد غير كاف من GCO']);
    exit;
}

// خصم GCO وإضافة السيولة
updateBalance($pdo, $userId, MAIN_CURRENCY_ID, -$amount);

$newLiquidity = $currency['liquidity'] + $amount;
$stmt = $pdo->prepare("UPDATE currencies SET liquidity = ? WHERE id = ?");
$stmt->execute([$newLiquidity, $currencyId]);

// تحديث السعر
updateCurrencyPrice($pdo, $currencyId);

// تسجيل المعاملة
addTransaction($pdo, $userId, 0, MAIN_CURRENCY_ID, $amount, 'إضافة سيولة لعملة ' . $currency['name']);

echo json_encode(['success' => true, 'message' => 'تمت إضافة السيولة بنجاح']);
?>