<?php
require_once 'config.php';
requireAuth();

$pdo = getDB();
$userId = $_SESSION['user_id'];

// استقبال البيانات من FormData
$amount = floatval($_POST['amount'] ?? 0);
$transactionId = $_POST['transaction_id'] ?? '';
$senderName = $_POST['sender_name'] ?? '';
$receiptImage = $_FILES['receipt_image'] ?? null;

if ($amount <= 0 || empty($transactionId) || empty($senderName) || !$receiptImage) {
    echo json_encode(['error' => 'الرجاء تعبئة جميع الحقول ورفع الإيصال']);
    exit;
}

$amountIqd = $amount * GCO_TO_IQD;

// حفظ الصورة
$imagePath = null;
if ($receiptImage && $receiptImage['error'] === 0) {
    $ext = pathinfo($receiptImage['name'], PATHINFO_EXTENSION);
    $filename = time() . '_' . $userId . '_' . rand(1000, 9999) . '.' . $ext;
    $filepath = __DIR__ . '/uploads/deposits/' . $filename;
    move_uploaded_file($receiptImage['tmp_name'], $filepath);
    $imagePath = '/api/uploads/deposits/' . $filename;
}

$stmt = $pdo->prepare("
    INSERT INTO deposit_requests (user_id, amount, amount_iqd, transaction_id, sender_name, receipt_image, status, created_at) 
    VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)
");
$stmt->execute([$userId, $amount, $amountIqd, $transactionId, $senderName, $imagePath, time()]);

echo json_encode([
    'success' => true,
    'message' => 'تم إرسال طلب الشحن بنجاح، سيتم المراجعة من قبل الإدارة'
]);
?>