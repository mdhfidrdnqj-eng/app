<?php
require_once 'config.php';
requireAuth();

$pdo = getDB();
$userId = $_SESSION['user_id'];

$currencyId = $_GET['id'] ?? '';

if (!$currencyId) {
    echo json_encode(['error' => 'معرف العملة مطلوب']);
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM currencies WHERE id = ?");
$stmt->execute([$currencyId]);
$currency = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$currency) {
    echo json_encode(['error' => 'العملة غير موجودة']);
    exit;
}

$priceHistory = json_decode($currency['price_history'], true) ?: [];
$currency['price_change'] = calculatePriceChange($priceHistory);
$currency['price_history'] = $priceHistory;

$userBalance = getUserBalance($pdo, $userId, $currencyId);

// جلب آخر 10 معاملات لهذه العملة
$stmt = $pdo->prepare("
    SELECT t.*, 
           u1.name as from_name, u2.name as to_name
    FROM transactions t
    LEFT JOIN users u1 ON t.from_user_id = u1.id
    LEFT JOIN users u2 ON t.to_user_id = u2.id
    WHERE t.currency_id = ? 
    ORDER BY t.ts DESC LIMIT 10
");
$stmt->execute([$currencyId]);
$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
    'success' => true,
    'currency' => $currency,
    'user_balance' => $userBalance,
    'recent_transactions' => $transactions,
    'gco_to_iqd' => GCO_TO_IQD
]);
?>